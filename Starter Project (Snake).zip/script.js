const map = L.map("map").setView([7.4443, 3.8996], 16);

L.tileLayer(
    "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    {
        attribution: "© OpenStreetMap"
    }
).addTo(map);

const locations = [

    // HALLS
    {
        name: "Trenchard Hall",
        category: "Hall",
        description: "A major lecture and event hall at the University of Ibadan.",
        lat: 7.44535,
        lng: 3.89775
    },

    {
        name: "Mellanby Hall",
        category: "Hall",
        description: "One of the student residential halls at the University of Ibadan.",
        lat: 7.44520,
        lng: 3.89820
    },

    {
        name: "Tedder Hall",
        category: "Hall",
        description: "A student residential hall at the University of Ibadan.",
        lat: 7.44500,
        lng: 3.89720
    },

    {
        name: "Kuti Hall",
        category: "Hall",
        description: "A student residential hall on the University of Ibadan campus.",
        lat: 7.44620,
        lng: 3.90120
    },

    {
        name: "Sultan Bello Hall",
        category: "Hall",
        description: "A student residential hall at the University of Ibadan.",
        lat: 7.44600,
        lng: 3.90050
    },

    {
        name: "Nnamdi Azikiwe Hall",
        category: "Hall",
        description: "A student residential hall at the University of Ibadan.",
        lat: 7.44530,
        lng: 3.90200
    },

    {
        name: "Independence Hall",
        category: "Hall",
        description: "A student residential hall at the University of Ibadan.",
        lat: 7.44400,
        lng: 3.90300
    },

    {
        name: "Queen Elizabeth II Hall",
        category: "Hall",
        description: "A female student residential hall at the University of Ibadan.",
        lat: 7.44300,
        lng: 3.90400
    },


    // HOSTELS
    {
        name: "Abadina Hostel",
        category: "Hostel",
        description: "Student accommodation located around the University of Ibadan campus.",
        lat: 7.44800,
        lng: 3.89550
    },

    {
        name: "Abadina Staff Quarters",
        category: "Hostel",
        description: "Residential accommodation within the University area.",
        lat: 7.44850,
        lng: 3.89600
    },

    {
        name: "Kuti Hostel",
        category: "Hostel",
        description: "Student accommodation near Kuti Hall.",
        lat: 7.44650,
        lng: 3.90150
    },

    {
        name: "Sultan Bello Hostel",
        category: "Hostel",
        description: "Student accommodation near Sultan Bello Hall.",
        lat: 7.44620,
        lng: 3.90070
    },


    // LIBRARY
    {
        name: "Kenneth Dike Library",
        category: "Library",
        description: "The main university library serving students and researchers.",
        lat: 7.44635,
        lng: 3.89664
    },


    // FACULTY
    {
        name: "Faculty of Arts",
        category: "Faculty",
        description: "Academic faculty offering programmes in the arts and humanities.",
        lat: 7.44610,
        lng: 3.89685
    },


    // STUDENT CENTRE
    {
        name: "Students' Union Building",
        category: "Student Centre",
        description: "A central location for student activities and union affairs.",
        lat: 7.44465,
        lng: 3.89935
    },


    // ENTRANCES
    {
        name: "University Main Gate",
        category: "Entrance",
        description: "A major entrance into the University of Ibadan campus.",
        lat: 7.44155,
        lng: 3.90095
    },

    {
        name: "Ajibode Gate",
        category: "Entrance",
        description: "An entrance providing access to the University area.",
        lat: 7.45400,
        lng: 3.89400
    },

    {
        name: "Second Gate",
        category: "Entrance",
        description: "Another access point to the University campus.",
        lat: 7.44250,
        lng: 3.90450
    },


    // RELIGIOUS
    {
        name: "University of Ibadan Central Mosque",
        category: "Religious",
        description: "A Muslim place of worship serving members of the University community.",
        lat: 7.44480,
        lng: 3.90100
    },

    {
        name: "St. Thomas Aquinas Catholic Church",
        category: "Religious",
        description: "A Catholic place of worship serving the University community.",
        lat: 7.44550,
        lng: 3.90000
    },

    {
        name: "University Christian Fellowship",
        category: "Religious",
        description: "A Christian fellowship associated with the University community.",
        lat: 7.44420,
        lng: 3.89850
    },
    // HEALTH
    {
        name: "University Health Centre",
        category: "Health",
        description: "University health facility providing healthcare services to the University community.",
        lat: 7.44450,
        lng: 3.90150
    },
// SPORTS
{
    name: "Old Sports Complex",
    category: "Sports",
    description: "Sports complex located between the Faculty of Education, Kenneth Dike Library and Faculty of the Social Sciences.",
    lat: 7.44600,
    lng: 3.89800
},

{
    name: "New Sports Complex",
    category: "Sports",
    description: "Sports complex near Obafemi Awolowo Hall with a football pitch, track and gymnasium.",
    lat: 7.44300,
    lng: 3.90500
},

{
    name: "University Gymnasium",
    category: "Sports",
    description: "University sports and fitness facility.",
    lat: 7.44550,
    lng: 3.89850
},

// SERVICES
{
    name: "University Bookshop",
    category: "Services",
    description: "University-owned bookshop serving the campus community.",
    lat: 7.44500,
    lng: 3.89900
},

{
    name: "Computing Centre",
    category: "Services",
    description: "Central computing facility providing computing and network-related services to students and staff.",
    lat: 7.44400,
    lng: 3.89650
},

{
    name: "University Canteen",
    category: "Services",
    description: "Campus food and dining facility.",
    lat: 7.44600,
    lng: 3.89900
}

];

let markers = [];

function showLocations(category) {

    markers.forEach(function(marker) {
        map.removeLayer(marker);
    });

    markers = [];

    locations.forEach(function(location) {

        if (category === "All" || location.category === category) {

          const marker = L.marker([
    location.lat,
    location.lng
], {
    title: location.name,
    icon: createPlaceIcon(location.category)
})
            .addTo(map)
            
    .bindPopup(
    "<div class='location-popup'>" +
        "<h3>" + location.name + "</h3>" +
        "<p>" + location.category + "</p>" +
        "<p>" + location.description + "</p>" +
        "<button onclick='startDirections(" +
            location.lat + "," +
            location.lng +
        ")'>🚶 Get Directions</button>" +
    "</div>"
);

            markers.push(marker);
        }
    });
}
showLocations("All");
const categoryButtons =
    document.querySelectorAll(".category-btn");

categoryButtons.forEach(function(button) {

    button.addEventListener("click", function() {

        categoryButtons.forEach(function(btn) {
            btn.classList.remove("active");
        });

        button.classList.add("active");

        const category =
            button.getAttribute("data-category");

        // Filter markers on the map
        showLocations(category);

        // Filter places on the Places page
        displayPlacesByCategory(category);

    });

});
const search = document.getElementById("search");
const suggestions = document.getElementById("suggestions");

search.addEventListener("input", function() {

    const text = search.value.toLowerCase();

    suggestions.innerHTML = "";

    if (text === "") {
        return;
    }

    const results = locations.filter(function(location) {

    return (
        location.name.toLowerCase().includes(text) ||
        location.category.toLowerCase().includes(text)
    );

});


    results.forEach(function(location) {

        const item = document.createElement("div");

        item.className = "suggestion";

        item.textContent = location.name;

        item.addEventListener("click", function() {

            map.setView(
                [location.lat, location.lng],
                18
            );

            L.popup()
                .setLatLng([location.lat, location.lng])
                .setContent(
                    "<b>" + location.name + "</b><br>" +
                    location.category
                )
                .openOn(map);

            search.value = location.name;

            suggestions.innerHTML = "";

        });

        suggestions.appendChild(item);

    });

});

const locationButton = document.getElementById("location-btn");

locationButton.addEventListener("click", function() {

    if (!navigator.geolocation) {
        alert("Your browser does not support location services.");
        return;
    }

    locationButton.textContent = "📍 Finding...";

    navigator.geolocation.getCurrentPosition(

        function(position) {

            const lat = position.coords.latitude;
            const lng = position.coords.longitude;

            console.log("Latitude:", lat);
            console.log("Longitude:", lng);

            map.setView([lat, lng], 18);

            L.marker([lat, lng])
                .addTo(map)
                .bindPopup("📍 You are here")
                .openPopup();

            locationButton.textContent = "📍 Find My Location";
        },

        function(error) {

            locationButton.textContent = "📍 Find My Location";

            if (error.code === 1) {
                alert("Location permission was denied.");
            }

            else if (error.code === 2) {
                alert("Your location could not be found.");
            }

            else if (error.code === 3) {
                alert("Location request timed out. Try again.");
            }

            else {
                alert("Something went wrong while finding your location.");
            }

        },

        {
            enableHighAccuracy: true,
            timeout: 15000,
            maximumAge: 0
        }

    );

});

let routingControl = null;

function startDirections(lat, lng) {

    if (!navigator.geolocation) {
        alert("Your browser does not support location services.");
        return;
    }

    navigator.geolocation.getCurrentPosition(

        function(position) {

            const userLat = position.coords.latitude;
            const userLng = position.coords.longitude;

            if (routingControl !== null) {
                map.removeControl(routingControl);
            }

            routingControl = L.Routing.control({

                waypoints: [

                    L.latLng(userLat, userLng),

                    L.latLng(lat, lng)

                ],

                routeWhileDragging: false,

                showAlternatives: false,

                lineOptions: {
                    styles: [
                        {
                            color: "#06B6D4",
                            opacity: 0.9,
                            weight: 6
                        }
                    ]
                }

            }).addTo(map);

        },

        function() {

            alert(
                "Your current location could not be accessed. " +
                "Please allow location access in your browser."
            );

        }

    );

}

document.getElementById("zoom-in").addEventListener("click", function() {
    map.zoomIn();
});

document.getElementById("zoom-out").addEventListener("click", function() {
    map.zoomOut();
});

const navItems = document.querySelectorAll(".nav-item");

const mapPage = document.getElementById("map-page");
const placesPage = document.getElementById("places-page");
const directionsPage = document.getElementById("directions-page");
const aboutPage = document.getElementById("about-page");

const placesList = document.getElementById("places-list");


function showPage(pageName) {

    // Hide all pages
    mapPage.style.display = "none";
    placesPage.style.display = "none";
    directionsPage.style.display = "none";
    aboutPage.style.display = "none";


    // MAP
    if (pageName === "map-section") {

        mapPage.style.display = "block";

        setTimeout(function() {
            map.invalidateSize();
        }, 300);

    }


    // PLACES
    if (pageName === "places-section") {

        placesPage.style.display = "block";

    }


    // DIRECTIONS
    if (pageName === "directions-section") {

        directionsPage.style.display = "block";

    }


    // ABOUT
    if (pageName === "about-section") {

        aboutPage.style.display = "block";

    }

}


// BOTTOM NAVIGATION

navItems.forEach(function(button) {

    button.addEventListener("click", function() {

        // Remove active from all buttons
        navItems.forEach(function(item) {
            item.classList.remove("active");
        });

        // Make clicked button active
        button.classList.add("active");

        // Get the page name
        const pageName =
            button.getAttribute("data-section");

        // Show the selected page
        showPage(pageName);

    });

});


// DISPLAY PLACES

function displayPlaces() {

    placesList.innerHTML = "";

    locations.forEach(function(location) {

        const card = document.createElement("div");

        card.className = "place-card";

        card.innerHTML = `
            <h3>${location.name}</h3>

            <div class="place-category">
                ${location.category}
            </div>

            <p class="place-description">
                ${location.description}
            </p>

          <div class="place-card-actions">

    <button
        onclick="showPlaceOnMap(
            ${location.lat},
            ${location.lng}
        )">
        🗺️ Show on Map
    </button>

    <button
        class="directions-btn"
        onclick="startDirections(
            ${location.lat},
            ${location.lng}
        )">
        🚶 Directions
    </button>

</div>
        `;
        placesList.appendChild(card);

    });

}


// SHOW PLACE ON MAP

function showPlaceOnMap(lat, lng) {

    // Switch to map page
    showPage("map-section");

    // Make Map button active
    navItems.forEach(function(item) {
        item.classList.remove("active");

        if (
            item.getAttribute("data-section") ===
            "map-section"
        ) {
            item.classList.add("active");
        }
    });

    // Move map to location
    map.setView([lat, lng], 18);

    // Show popup
    L.popup()
        .setLatLng([lat, lng])
        .setContent("📍 Selected location")
        .openOn(map);

}
function getPlaceIcon(category) {

    if (category === "Hall") return "🏠";

    if (category === "Hostel") return "🛏️";

    if (category === "Faculty") return "🎓";
if (category === "Student Centre") return "🏛️";
   
    if (category === "Library") return "📚";

    if (category === "Entrance") return "🚪";

    if (category === "Religious") return "⛪";

    if (category === "Health") return "🏥";

    if (category === "Sports") return "🏃";

    if (category === "Services") return "🛍️";

    return "📍";
}

function createPlaceIcon(category) {

    const icon = getPlaceIcon(category);

    let markerColor = "#06B6D4";

    if (category === "Hall") {
        markerColor = "#3B82F6";
    }

    else if (category === "Hostel") {
        markerColor = "#8B5CF6";
    }

    else if (category === "Faculty") {
        markerColor = "#10B981";
    }

    else if (category === "Student Centre") {
        markerColor = "#F59E0B";
    }

    else if (category === "Library") {
        markerColor = "#F97316";
    }

    else if (category === "Entrance") {
        markerColor = "#EF4444";
    }

    else if (category === "Religious") {
        markerColor = "#EAB308";
    }

    else if (category === "Health") {
        markerColor = "#EC4899";
    }

    else if (category === "Sports") {
        markerColor = "#14B8A6";
    }

    else if (category === "Services") {
        markerColor = "#6366F1";
    }

    return L.divIcon({

        className: "custom-place-marker",

        html: `
            <div
                class="place-marker"
                style="background:${markerColor};"
            >
                ${icon}
            </div>
        `,

        iconSize: [42, 42],

        iconAnchor: [21, 21],

        popupAnchor: [0, -21]

    });

}

// DISPLAY ALL PLACES
displayPlaces();

const placesSearchInput =
    document.getElementById("places-search-input");

if (placesSearchInput) {

    placesSearchInput.addEventListener("input", function() {

        const searchTerm =
            placesSearchInput.value.toLowerCase().trim();

        const filteredLocations =
            locations.filter(function(location) {

                return (
                    location.name.toLowerCase().includes(searchTerm) ||
                    location.category.toLowerCase().includes(searchTerm) ||
                    location.description.toLowerCase().includes(searchTerm)
                );

            });

        placesList.innerHTML = "";

        filteredLocations.forEach(function(location) {

            const card = document.createElement("div");

            card.className = "place-card";

            card.innerHTML = `
                <div class="place-card-top">

                    <div class="place-icon">
                        ${getPlaceIcon(location.category)}
                    </div>

                    <div>

                        <h3>
                            ${location.name}
                        </h3>

                        <div class="place-category">
                            ${location.category}
                        </div>

                    </div>

                </div>

                <p class="place-description">
                    ${location.description}
                </p>
                    <div class="place-card-actions">

    <button
        onclick="showPlaceOnMap(
            ${location.lat},
            ${location.lng}
        )">
        🗺️ Show on Map
    </button>

    <button
        class="directions-btn"
        onclick="startDirections(
            ${location.lat},
            ${location.lng}
        )">
        🚶 Directions
    </button>

</div>
            `;
            placesList.appendChild(card);

        });

    });

}

function displayPlacesByCategory(category) {
    placesList.innerHTML = "";

    const filteredLocations =
        category === "All"
            ? locations
            : locations.filter(function(location) {
                return location.category === category;
            });

    filteredLocations.forEach(function(location) {
        const card = document.createElement("div");
        card.className = "place-card";

        card.innerHTML = `
            <div class="place-card-top">

                <div class="place-icon">
                    ${getPlaceIcon(location.category)}
                </div>

                <div>
                    <h3>${location.name}</h3>

                    <div class="place-category">
                        ${location.category}
                    </div>
                </div>

            </div>

            <p class="place-description">
                ${location.description}
            </p>

            <div class="place-card-actions">

                <button
                    onclick="showPlaceOnMap(
                        ${location.lat},
                        ${location.lng}
                    )">
                    🗺️ Show on Map
                </button>

                <button
                    class="directions-btn"
                    onclick="startDirections(
                        ${location.lat},
                        ${location.lng}
                    )">
                    🚶 Directions
                </button>

            </div>
        `;

        placesList.appendChild(card);
    });
}

// START WITH MAP
showPage("map-section");
